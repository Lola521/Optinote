"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = getValue;
function getValue({ value }) {
    return value;
}
module.exports = exports["default"];