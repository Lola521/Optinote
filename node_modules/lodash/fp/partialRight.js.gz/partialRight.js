var convert = require('./convert'),
    func = convert('partialRight', require('../partialRight'));

func.placeholder = require('./placeholder');
module.exports = func;
