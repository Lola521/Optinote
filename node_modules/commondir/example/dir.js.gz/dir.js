var commondir = require('../');
var dir = commondir(process.argv.slice(2));
console.log(dir);
