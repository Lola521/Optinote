'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = addSpace;
function addSpace() {
    return { type: 'space', value: ' ' };
}
module.exports = exports['default'];