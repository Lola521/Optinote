var createWalker = require('./create');
var config = require('../syntax/config/walker');

module.exports = createWalker(config);
