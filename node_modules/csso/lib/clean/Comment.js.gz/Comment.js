module.exports = function cleanComment(data, item, list) {
    list.remove(item);
};
