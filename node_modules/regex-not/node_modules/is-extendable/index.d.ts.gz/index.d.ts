export = isExtendable;

declare function isExtendable(val: any): boolean;

declare namespace isExtendable {}
