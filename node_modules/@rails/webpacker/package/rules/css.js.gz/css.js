const getStyleRule = require('../utils/get_style_rule')

module.exports = getStyleRule(/\.(css)$/i)
