const ConfigObject = require('./config_object')
const ConfigList = require('./config_list')

module.exports = {
  ConfigObject,
  ConfigList
}
