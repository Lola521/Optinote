"use strict";

const plugin = require('./index');

module.exports = plugin.default;