'use strict';

module.exports = 8080;
