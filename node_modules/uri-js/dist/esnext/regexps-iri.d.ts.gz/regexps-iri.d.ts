import { URIRegExps } from "./uri";
declare const _default: URIRegExps;
export default _default;
