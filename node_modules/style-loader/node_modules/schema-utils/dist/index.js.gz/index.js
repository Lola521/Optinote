"use strict";

const validate = require('./validate');

module.exports = validate.default;