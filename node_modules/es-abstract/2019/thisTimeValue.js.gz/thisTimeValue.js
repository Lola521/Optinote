'use strict';

module.exports = require('../2018/thisTimeValue');
