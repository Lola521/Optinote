module.exports = require('is-arguments');
