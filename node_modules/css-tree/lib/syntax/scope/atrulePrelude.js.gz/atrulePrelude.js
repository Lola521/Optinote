module.exports = {
    getNode: require('./default')
};
