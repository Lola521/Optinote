var createConvertor = require('./create');

module.exports = createConvertor(require('../walker'));
