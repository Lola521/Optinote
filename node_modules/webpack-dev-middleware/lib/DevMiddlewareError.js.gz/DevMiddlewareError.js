'use strict';

module.exports = class DevMiddlewareError extends Error {};
