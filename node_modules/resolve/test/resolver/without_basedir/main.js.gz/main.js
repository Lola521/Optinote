var resolve = require('../../../');

module.exports = function (t, cb) {
    resolve('mymodule', null, cb);
};
