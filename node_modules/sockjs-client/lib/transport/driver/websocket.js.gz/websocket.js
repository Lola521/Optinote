module.exports = require('faye-websocket').Client;
