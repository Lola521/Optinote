module.exports = require('eventsource');
