module.exports = global.EventSource;
