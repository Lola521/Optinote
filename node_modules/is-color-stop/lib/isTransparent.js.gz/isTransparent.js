'use strict';

function isTransparent(str) {
  return str === 'transparent';
}

module.exports = isTransparent;
