// This file is for backward compatibility with v0.5.1.
require('./register')

console.warn("'json5/require' is deprecated. Please use 'json5/register' instead.")
