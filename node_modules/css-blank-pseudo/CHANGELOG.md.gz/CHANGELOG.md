# Changes to CSS Blank Pseudo

### 0.1.4 (November 17, 2018)

- Update documentation

### 0.1.3 (November 17, 2018)

- Improve CLI usage

### 0.1.2 (November 17, 2018)

- Provide a version specifically for Internet Explorer 11

### 0.1.1 (November 17, 2018)

- Update documentation

### 0.1.0 (November 17, 2018)

- Initial version
