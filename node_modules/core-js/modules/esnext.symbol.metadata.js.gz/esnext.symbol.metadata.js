var defineWellKnownSymbol = require('../internals/define-well-known-symbol');

// `Symbol.metadata` well-known symbol
// https://github.com/tc39/proposal-decorators
defineWellKnownSymbol('metadata');
