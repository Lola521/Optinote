require('../../modules/es.regexp.exec');
require('../../modules/es.string.replace');
require('../../modules/es.string.replace-all');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'replaceAll');
