require('../../modules/es.string.big');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'big');
