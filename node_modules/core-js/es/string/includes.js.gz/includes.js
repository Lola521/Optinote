require('../../modules/es.string.includes');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'includes');
