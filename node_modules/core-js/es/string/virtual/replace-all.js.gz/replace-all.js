require('../../../modules/es.regexp.exec');
require('../../../modules/es.string.replace');
require('../../../modules/es.string.replace-all');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').replaceAll;
