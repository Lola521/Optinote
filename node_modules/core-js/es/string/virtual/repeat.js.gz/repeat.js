require('../../../modules/es.string.repeat');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').repeat;
