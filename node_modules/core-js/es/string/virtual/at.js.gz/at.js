require('../../../modules/es.string.at-alternative');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').at;
