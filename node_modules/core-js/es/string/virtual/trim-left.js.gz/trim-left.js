require('../../../modules/es.string.trim-start');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').trimLeft;
