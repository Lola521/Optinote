require('../../../modules/es.string.anchor');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').anchor;
