require('../../modules/es.string.strike');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'strike');
