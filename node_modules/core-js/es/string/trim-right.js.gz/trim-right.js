require('../../modules/es.string.trim-end');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'trimRight');
