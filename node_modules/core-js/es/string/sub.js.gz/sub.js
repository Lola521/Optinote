require('../../modules/es.string.sub');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'sub');
