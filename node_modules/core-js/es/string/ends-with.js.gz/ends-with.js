require('../../modules/es.string.ends-with');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'endsWith');
