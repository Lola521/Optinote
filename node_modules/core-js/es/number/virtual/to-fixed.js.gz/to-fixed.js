require('../../../modules/es.number.to-fixed');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Number').toFixed;
