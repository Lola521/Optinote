require('../../modules/es.number.is-safe-integer');
var path = require('../../internals/path');

module.exports = path.Number.isSafeInteger;
