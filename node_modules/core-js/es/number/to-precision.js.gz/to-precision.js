require('../../modules/es.number.to-precision');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Number', 'toPrecision');
