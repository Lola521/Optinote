require('../../modules/es.error.to-string');
var toString = require('../../internals/error-to-string');

module.exports = toString;
