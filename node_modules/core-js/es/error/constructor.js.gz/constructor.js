require('../../modules/es.error.cause');
var path = require('../../internals/path');

module.exports = path;
