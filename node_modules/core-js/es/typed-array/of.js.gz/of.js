require('../../modules/es.typed-array.of');
