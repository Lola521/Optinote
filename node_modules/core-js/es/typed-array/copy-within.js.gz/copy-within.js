require('../../modules/es.typed-array.copy-within');
