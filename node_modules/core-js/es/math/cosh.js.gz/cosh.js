require('../../modules/es.math.cosh');
var path = require('../../internals/path');

module.exports = path.Math.cosh;
