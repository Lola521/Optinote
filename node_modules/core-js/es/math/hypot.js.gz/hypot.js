require('../../modules/es.math.hypot');
var path = require('../../internals/path');

module.exports = path.Math.hypot;
