require('../../modules/es.math.expm1');
var path = require('../../internals/path');

module.exports = path.Math.expm1;
