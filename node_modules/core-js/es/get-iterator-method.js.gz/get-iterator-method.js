require('../modules/es.array.iterator');
require('../modules/es.string.iterator');
var getIteratorMethod = require('../internals/get-iterator-method');

module.exports = getIteratorMethod;
