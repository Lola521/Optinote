require('../../modules/es.array.flat-map');
require('../../modules/es.array.unscopables.flat-map');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'flatMap');
