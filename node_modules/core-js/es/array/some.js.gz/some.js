require('../../modules/es.array.some');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'some');
