require('../../modules/es.array.reduce');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'reduce');
