require('../../modules/es.array.splice');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'splice');
