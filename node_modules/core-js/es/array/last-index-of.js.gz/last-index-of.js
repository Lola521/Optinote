require('../../modules/es.array.last-index-of');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'lastIndexOf');
