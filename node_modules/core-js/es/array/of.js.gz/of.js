require('../../modules/es.array.of');
var path = require('../../internals/path');

module.exports = path.Array.of;
