require('../../modules/es.symbol.async-iterator');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('asyncIterator');
