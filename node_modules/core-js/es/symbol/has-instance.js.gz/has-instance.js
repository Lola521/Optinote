require('../../modules/es.symbol.has-instance');
require('../../modules/es.function.has-instance');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('hasInstance');
