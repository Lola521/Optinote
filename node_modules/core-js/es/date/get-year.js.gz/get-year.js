require('../../modules/es.date.get-year');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Date', 'getYear');
