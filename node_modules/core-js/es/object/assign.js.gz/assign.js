require('../../modules/es.object.assign');
var path = require('../../internals/path');

module.exports = path.Object.assign;
