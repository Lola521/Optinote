require('../../modules/es.object.values');
var path = require('../../internals/path');

module.exports = path.Object.values;
