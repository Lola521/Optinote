require('../modules/es.global-this');

module.exports = require('../internals/global');
