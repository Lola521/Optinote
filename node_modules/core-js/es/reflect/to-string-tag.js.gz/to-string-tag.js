require('../../modules/es.object.to-string');
require('../../modules/es.reflect.to-string-tag');

module.exports = 'Reflect';
