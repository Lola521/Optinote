require('../../modules/es.reflect.construct');
var path = require('../../internals/path');

module.exports = path.Reflect.construct;
