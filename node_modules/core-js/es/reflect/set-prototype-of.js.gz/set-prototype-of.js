require('../../modules/es.reflect.set-prototype-of');
var path = require('../../internals/path');

module.exports = path.Reflect.setPrototypeOf;
