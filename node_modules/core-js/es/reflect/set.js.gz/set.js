require('../../modules/es.reflect.set');
var path = require('../../internals/path');

module.exports = path.Reflect.set;
