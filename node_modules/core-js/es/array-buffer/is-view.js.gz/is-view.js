require('../../modules/es.array-buffer.is-view');
var path = require('../../internals/path');

module.exports = path.ArrayBuffer.isView;
