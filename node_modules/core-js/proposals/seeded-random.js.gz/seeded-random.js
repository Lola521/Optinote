// https://github.com/tc39/proposal-seeded-random
require('../modules/esnext.math.seeded-prng');
