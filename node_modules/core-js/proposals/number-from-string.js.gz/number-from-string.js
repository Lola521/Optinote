// https://github.com/tc39/proposal-number-fromstring
require('../modules/esnext.number.from-string');
