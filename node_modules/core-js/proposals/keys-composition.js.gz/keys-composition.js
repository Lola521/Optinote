// https://github.com/tc39/proposal-richer-keys/tree/master/compositeKey
require('../modules/esnext.composite-key');
require('../modules/esnext.composite-symbol');
