// https://github.com/bathos/proposal-string-cooked
require('../modules/esnext.string.cooked');
