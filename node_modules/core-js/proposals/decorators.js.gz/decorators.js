// https://github.com/tc39/proposal-decorators
require('../modules/esnext.symbol.metadata');
