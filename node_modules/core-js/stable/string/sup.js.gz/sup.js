var parent = require('../../es/string/sup');

module.exports = parent;
