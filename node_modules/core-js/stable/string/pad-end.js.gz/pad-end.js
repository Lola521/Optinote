var parent = require('../../es/string/pad-end');

module.exports = parent;
