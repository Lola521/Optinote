var parent = require('../../es/string/sub');

module.exports = parent;
