var parent = require('../../../es/string/virtual/substr');

module.exports = parent;
