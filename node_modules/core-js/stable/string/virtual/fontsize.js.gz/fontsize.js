var parent = require('../../../es/string/virtual/fontsize');

module.exports = parent;
