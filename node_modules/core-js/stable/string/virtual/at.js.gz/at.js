var parent = require('../../../es/string/virtual/at');

module.exports = parent;
