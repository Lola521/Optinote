var parent = require('../../../es/string/virtual/bold');

module.exports = parent;
