var parent = require('../../../es/string/virtual/trim-end');

module.exports = parent;
