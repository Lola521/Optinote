var parent = require('../../../es/string/virtual/includes');

module.exports = parent;
