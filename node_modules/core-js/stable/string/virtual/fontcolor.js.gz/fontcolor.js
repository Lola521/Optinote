var parent = require('../../../es/string/virtual/fontcolor');

module.exports = parent;
