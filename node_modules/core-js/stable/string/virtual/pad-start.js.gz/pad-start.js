var parent = require('../../../es/string/virtual/pad-start');

module.exports = parent;
