var parent = require('../../../es/string/virtual/replace-all');

module.exports = parent;
