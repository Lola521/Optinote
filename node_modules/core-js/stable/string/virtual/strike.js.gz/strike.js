var parent = require('../../../es/string/virtual/strike');

module.exports = parent;
