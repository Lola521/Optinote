var parent = require('../../es/string/raw');

module.exports = parent;
