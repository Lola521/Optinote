var parent = require('../../es/string/anchor');

module.exports = parent;
