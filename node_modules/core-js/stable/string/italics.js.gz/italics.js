var parent = require('../../es/string/italics');

module.exports = parent;
