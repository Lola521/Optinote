var parent = require('../../es/string/ends-with');

module.exports = parent;
