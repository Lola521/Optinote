var parent = require('../../es/string/pad-start');

module.exports = parent;
