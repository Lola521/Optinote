var parent = require('../../es/json');

module.exports = parent;
