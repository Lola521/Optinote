var parent = require('../../es/regexp/flags');

module.exports = parent;
