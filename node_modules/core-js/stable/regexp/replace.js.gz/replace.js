var parent = require('../../es/regexp/replace');

module.exports = parent;
