var parent = require('../../es/regexp/search');

module.exports = parent;
