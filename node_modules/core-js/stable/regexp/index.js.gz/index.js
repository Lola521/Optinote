var parent = require('../../es/regexp');

module.exports = parent;
