var parent = require('../../es/typed-array/methods');

module.exports = parent;
