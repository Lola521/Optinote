var parent = require('../../es/typed-array/keys');

module.exports = parent;
