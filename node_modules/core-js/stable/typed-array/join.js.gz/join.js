var parent = require('../../es/typed-array/join');

module.exports = parent;
