var parent = require('../../es/typed-array/sort');

module.exports = parent;
