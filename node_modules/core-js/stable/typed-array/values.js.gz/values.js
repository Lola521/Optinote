var parent = require('../../es/typed-array/values');

module.exports = parent;
