var parent = require('../../es/typed-array/int32-array');
require('../../stable/typed-array/methods');

module.exports = parent;
