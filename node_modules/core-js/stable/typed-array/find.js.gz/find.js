var parent = require('../../es/typed-array/find');

module.exports = parent;
