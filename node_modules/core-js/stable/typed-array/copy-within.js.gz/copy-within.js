var parent = require('../../es/typed-array/copy-within');

module.exports = parent;
