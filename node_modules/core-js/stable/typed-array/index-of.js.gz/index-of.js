var parent = require('../../es/typed-array/index-of');

module.exports = parent;
