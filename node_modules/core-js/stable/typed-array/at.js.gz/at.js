var parent = require('../../es/typed-array/at');

module.exports = parent;
