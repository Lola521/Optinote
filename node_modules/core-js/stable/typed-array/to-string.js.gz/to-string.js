var parent = require('../../es/typed-array/to-string');

module.exports = parent;
