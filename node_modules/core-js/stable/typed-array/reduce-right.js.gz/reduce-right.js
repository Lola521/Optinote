var parent = require('../../es/typed-array/reduce-right');

module.exports = parent;
