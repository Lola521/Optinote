var parent = require('../../es/typed-array/subarray');

module.exports = parent;
