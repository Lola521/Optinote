var parent = require('../../es/typed-array/of');

module.exports = parent;
