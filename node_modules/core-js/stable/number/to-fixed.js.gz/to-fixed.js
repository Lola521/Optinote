var parent = require('../../es/number/to-fixed');

module.exports = parent;
