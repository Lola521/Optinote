var parent = require('../../../es/number/virtual/to-exponential');

module.exports = parent;
