var parent = require('../../../es/number/virtual/to-precision');

module.exports = parent;
