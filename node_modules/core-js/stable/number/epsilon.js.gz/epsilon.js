var parent = require('../../es/number/epsilon');

module.exports = parent;
