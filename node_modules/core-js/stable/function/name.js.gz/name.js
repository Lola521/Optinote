var parent = require('../../es/function/name');

module.exports = parent;
