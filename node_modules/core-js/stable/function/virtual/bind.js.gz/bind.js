var parent = require('../../../es/function/virtual/bind');

module.exports = parent;
