// TODO: remove from `core-js@4`
require('../modules/esnext.aggregate-error');

var parent = require('../es/aggregate-error');
require('../modules/web.dom-collections.iterator');

module.exports = parent;
