require('../../modules/web.dom-exception.to-string-tag');

module.exports = 'DOMException';
