var parent = require('../../es/object/get-own-property-symbols');

module.exports = parent;
