var parent = require('../../es/object/define-getter');

module.exports = parent;
