var parent = require('../../es/object/define-property');

module.exports = parent;
