var parent = require('../../es/object/get-own-property-names');

module.exports = parent;
