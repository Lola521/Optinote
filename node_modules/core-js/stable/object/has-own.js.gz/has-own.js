var parent = require('../../es/object/has-own');

module.exports = parent;
