var parent = require('../../es/object/from-entries');
require('../../modules/web.dom-collections.iterator');

module.exports = parent;
