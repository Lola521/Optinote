var parent = require('../../es/object/values');

module.exports = parent;
