var parent = require('../../es/object');
require('../../modules/web.dom-collections.iterator');

module.exports = parent;
