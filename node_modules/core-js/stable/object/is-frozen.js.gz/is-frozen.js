var parent = require('../../es/object/is-frozen');

module.exports = parent;
