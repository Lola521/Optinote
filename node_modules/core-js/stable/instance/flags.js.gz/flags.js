var parent = require('../../es/instance/flags');

module.exports = parent;
