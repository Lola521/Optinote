var parent = require('../../es/instance/replace-all');

module.exports = parent;
