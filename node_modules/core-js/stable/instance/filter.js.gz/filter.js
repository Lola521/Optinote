var parent = require('../../es/instance/filter');

module.exports = parent;
