var parent = require('../../es/instance/index-of');

module.exports = parent;
