var parent = require('../../es/instance/last-index-of');

module.exports = parent;
