var parent = require('../../es/symbol');
require('../../modules/web.dom-collections.iterator');

module.exports = parent;
