var parent = require('../../es/symbol/iterator');
require('../../modules/web.dom-collections.iterator');

module.exports = parent;
