var parent = require('../../es/symbol/key-for');

module.exports = parent;
