var parent = require('../../es/symbol/replace');

module.exports = parent;
