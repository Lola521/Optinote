var parent = require('../../es/array');

module.exports = parent;
