var parent = require('../../es/array/every');

module.exports = parent;
