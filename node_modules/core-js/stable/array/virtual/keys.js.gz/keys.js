var parent = require('../../../es/array/virtual/keys');

module.exports = parent;
