var parent = require('../../../es/array/virtual/join');

module.exports = parent;
