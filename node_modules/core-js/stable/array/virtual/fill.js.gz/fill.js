var parent = require('../../../es/array/virtual/fill');

module.exports = parent;
