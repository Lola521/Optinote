var parent = require('../../es/array/entries');

module.exports = parent;
