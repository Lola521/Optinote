var parent = require('../../es/error');

module.exports = parent;
