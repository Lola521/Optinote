var parent = require('../../es/math/log2');

module.exports = parent;
