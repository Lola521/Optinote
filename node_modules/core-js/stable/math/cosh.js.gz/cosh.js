var parent = require('../../es/math/cosh');

module.exports = parent;
