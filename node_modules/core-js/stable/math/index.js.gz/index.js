var parent = require('../../es/math');

module.exports = parent;
