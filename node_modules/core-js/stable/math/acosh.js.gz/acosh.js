var parent = require('../../es/math/acosh');

module.exports = parent;
