var parent = require('../../es/date/to-gmt-string');

module.exports = parent;
