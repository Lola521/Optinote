var parent = require('../../es/date/set-year');

module.exports = parent;
