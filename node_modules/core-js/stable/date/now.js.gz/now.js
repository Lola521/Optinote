var parent = require('../../es/date/now');

module.exports = parent;
