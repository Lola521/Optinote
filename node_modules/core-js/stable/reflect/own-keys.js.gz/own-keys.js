var parent = require('../../es/reflect/own-keys');

module.exports = parent;
