var parent = require('../../es/reflect/get-own-property-descriptor');

module.exports = parent;
