var parent = require('../../es/reflect/get');

module.exports = parent;
