var parent = require('../../es/reflect/is-extensible');

module.exports = parent;
