This folder contains entry points for [ECMAScript proposals](https://github.com/zloirock/core-js/tree/v3#ecmascript-proposals) with dependencies.
