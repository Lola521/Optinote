require('../proposals/array-from-async');
require('../proposals/array-is-template-object');
require('../proposals/change-array-by-copy');
require('../proposals/decorators');
require('../proposals/iterator-helpers');
require('../proposals/map-upsert');
require('../proposals/set-methods');
require('../proposals/using-statement');
var parent = require('./3');

module.exports = parent;
