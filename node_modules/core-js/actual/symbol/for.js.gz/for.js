var parent = require('../../stable/symbol/for');

module.exports = parent;
