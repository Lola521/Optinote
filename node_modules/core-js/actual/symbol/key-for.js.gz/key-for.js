var parent = require('../../stable/symbol/key-for');

module.exports = parent;
