var parent = require('../../stable/symbol/async-iterator');

module.exports = parent;
