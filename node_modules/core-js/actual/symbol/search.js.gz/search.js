var parent = require('../../stable/symbol/search');

module.exports = parent;
