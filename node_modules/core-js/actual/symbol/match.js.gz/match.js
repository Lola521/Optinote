var parent = require('../../stable/symbol/match');

module.exports = parent;
