var parent = require('../../stable/symbol/to-string-tag');

module.exports = parent;
