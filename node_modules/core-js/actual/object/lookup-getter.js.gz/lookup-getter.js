var parent = require('../../stable/object/lookup-getter');

module.exports = parent;
