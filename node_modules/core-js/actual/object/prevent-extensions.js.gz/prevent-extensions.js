var parent = require('../../stable/object/prevent-extensions');

module.exports = parent;
