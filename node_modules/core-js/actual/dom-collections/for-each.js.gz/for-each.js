var parent = require('../../stable/dom-collections/for-each');

module.exports = parent;
