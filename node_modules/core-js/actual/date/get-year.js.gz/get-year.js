var parent = require('../../stable/date/get-year');

module.exports = parent;
