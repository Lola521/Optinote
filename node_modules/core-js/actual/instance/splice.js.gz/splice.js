var parent = require('../../stable/instance/splice');

module.exports = parent;
