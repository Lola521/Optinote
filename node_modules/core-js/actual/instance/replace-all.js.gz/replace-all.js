var parent = require('../../stable/instance/replace-all');

module.exports = parent;
