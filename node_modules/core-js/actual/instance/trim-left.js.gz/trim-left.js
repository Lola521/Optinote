var parent = require('../../stable/instance/trim-left');

module.exports = parent;
