var parent = require('../../stable/instance/copy-within');

module.exports = parent;
