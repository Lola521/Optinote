var parent = require('../../stable/instance/trim-end');

module.exports = parent;
