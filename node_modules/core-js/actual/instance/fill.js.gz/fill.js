var parent = require('../../stable/instance/fill');

module.exports = parent;
