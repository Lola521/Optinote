var parent = require('../../stable/url-search-params');

module.exports = parent;
