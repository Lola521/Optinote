var parent = require('../../../stable/array/virtual/splice');

module.exports = parent;
