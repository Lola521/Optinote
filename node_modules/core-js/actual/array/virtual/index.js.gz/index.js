var parent = require('../../../stable/array/virtual');
require('../../../modules/es.map');
require('../../../modules/es.object.to-string');
require('../../../modules/esnext.array.find-last');
require('../../../modules/esnext.array.find-last-index');
require('../../../modules/esnext.array.group-by');
require('../../../modules/esnext.array.group-by-to-map');

module.exports = parent;
