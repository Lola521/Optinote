var parent = require('../../stable/array/flat');

module.exports = parent;
