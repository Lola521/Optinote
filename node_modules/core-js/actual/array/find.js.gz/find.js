var parent = require('../../stable/array/find');

module.exports = parent;
