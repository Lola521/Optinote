var parent = require('../../stable/string');

module.exports = parent;
