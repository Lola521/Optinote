var parent = require('../../stable/string/raw');

module.exports = parent;
