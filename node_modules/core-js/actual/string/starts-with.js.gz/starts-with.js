var parent = require('../../stable/string/starts-with');

module.exports = parent;
