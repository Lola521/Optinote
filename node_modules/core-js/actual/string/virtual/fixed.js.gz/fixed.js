var parent = require('../../../stable/string/virtual/fixed');

module.exports = parent;
