var parent = require('../../../stable/string/virtual/strike');

module.exports = parent;
