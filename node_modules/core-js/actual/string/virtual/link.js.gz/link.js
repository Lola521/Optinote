var parent = require('../../../stable/string/virtual/link');

module.exports = parent;
