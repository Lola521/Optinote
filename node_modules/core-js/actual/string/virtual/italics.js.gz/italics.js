var parent = require('../../../stable/string/virtual/italics');

module.exports = parent;
