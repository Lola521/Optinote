var parent = require('../../../stable/string/virtual/replace-all');

module.exports = parent;
