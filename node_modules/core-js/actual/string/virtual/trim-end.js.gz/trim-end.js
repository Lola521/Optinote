var parent = require('../../../stable/string/virtual/trim-end');

module.exports = parent;
