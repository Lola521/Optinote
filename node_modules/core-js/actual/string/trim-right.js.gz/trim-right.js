var parent = require('../../stable/string/trim-right');

module.exports = parent;
