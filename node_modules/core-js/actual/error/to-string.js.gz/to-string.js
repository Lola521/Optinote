var parent = require('../../stable/error/to-string');

module.exports = parent;
