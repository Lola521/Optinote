var parent = require('../../stable/number/to-fixed');

module.exports = parent;
