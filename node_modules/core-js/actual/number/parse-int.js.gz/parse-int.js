var parent = require('../../stable/number/parse-int');

module.exports = parent;
