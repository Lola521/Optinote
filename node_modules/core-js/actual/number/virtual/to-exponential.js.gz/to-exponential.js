var parent = require('../../../stable/number/virtual/to-exponential');

module.exports = parent;
