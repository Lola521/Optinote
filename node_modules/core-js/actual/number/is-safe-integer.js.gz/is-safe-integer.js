var parent = require('../../stable/number/is-safe-integer');

module.exports = parent;
