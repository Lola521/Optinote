var parent = require('../../stable/regexp/split');

module.exports = parent;
