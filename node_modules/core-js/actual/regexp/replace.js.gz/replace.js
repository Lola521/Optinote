var parent = require('../../stable/regexp/replace');

module.exports = parent;
