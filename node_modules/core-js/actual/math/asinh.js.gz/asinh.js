var parent = require('../../stable/math/asinh');

module.exports = parent;
