var parent = require('../../stable/math');

module.exports = parent;
