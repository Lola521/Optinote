var parent = require('../../stable/math/clz32');

module.exports = parent;
