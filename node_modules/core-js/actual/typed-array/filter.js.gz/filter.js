var parent = require('../../stable/typed-array/filter');

module.exports = parent;
