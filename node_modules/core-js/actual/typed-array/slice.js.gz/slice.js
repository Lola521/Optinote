var parent = require('../../stable/typed-array/slice');

module.exports = parent;
