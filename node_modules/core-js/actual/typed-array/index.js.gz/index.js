var parent = require('../../stable/typed-array');
require('../../modules/esnext.typed-array.find-last');
require('../../modules/esnext.typed-array.find-last-index');

module.exports = parent;
