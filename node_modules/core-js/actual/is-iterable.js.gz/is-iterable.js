var parent = require('../stable/is-iterable');

module.exports = parent;
