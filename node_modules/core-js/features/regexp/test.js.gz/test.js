var parent = require('../../actual/regexp/test');

module.exports = parent;
