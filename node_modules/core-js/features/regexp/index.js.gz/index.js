var parent = require('../../actual/regexp');

module.exports = parent;
