var parent = require('../../actual/regexp/flags');

module.exports = parent;
