var parent = require('../../actual/regexp/sticky');

module.exports = parent;
