var parent = require('../../actual/regexp/to-string');

module.exports = parent;
