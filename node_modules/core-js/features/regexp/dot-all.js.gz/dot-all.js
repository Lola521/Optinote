var parent = require('../../actual/regexp/dot-all');

module.exports = parent;
