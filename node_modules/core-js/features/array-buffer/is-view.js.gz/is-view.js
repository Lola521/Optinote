var parent = require('../../actual/array-buffer/is-view');

module.exports = parent;
