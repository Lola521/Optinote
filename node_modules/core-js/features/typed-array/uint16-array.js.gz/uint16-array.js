var parent = require('../../actual/typed-array/uint16-array');
require('../../features/typed-array/methods');

module.exports = parent;
