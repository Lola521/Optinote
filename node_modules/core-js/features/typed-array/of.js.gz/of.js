var parent = require('../../actual/typed-array/of');

module.exports = parent;
