var parent = require('../../actual/typed-array/find-index');

module.exports = parent;
