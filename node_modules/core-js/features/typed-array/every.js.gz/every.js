var parent = require('../../actual/typed-array/every');

module.exports = parent;
