require('../../modules/esnext.typed-array.filter-reject');
