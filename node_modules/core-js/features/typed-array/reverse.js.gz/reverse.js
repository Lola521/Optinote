var parent = require('../../actual/typed-array/reverse');

module.exports = parent;
