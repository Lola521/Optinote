var parent = require('../../actual/typed-array/sort');

module.exports = parent;
