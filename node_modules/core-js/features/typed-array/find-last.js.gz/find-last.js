var parent = require('../../actual/typed-array/find-last');

module.exports = parent;
