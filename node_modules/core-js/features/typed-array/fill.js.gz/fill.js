var parent = require('../../actual/typed-array/fill');

module.exports = parent;
