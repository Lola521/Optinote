var parent = require('../../actual/typed-array/iterator');

module.exports = parent;
