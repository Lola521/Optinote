var parent = require('../../actual/typed-array/values');

module.exports = parent;
