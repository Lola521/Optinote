var parent = require('../actual/clear-immediate');

module.exports = parent;
