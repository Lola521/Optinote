var parent = require('../../actual/date/to-primitive');

module.exports = parent;
