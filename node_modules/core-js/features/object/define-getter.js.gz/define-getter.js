var parent = require('../../actual/object/define-getter');

module.exports = parent;
