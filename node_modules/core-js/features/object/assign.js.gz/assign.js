var parent = require('../../actual/object/assign');

module.exports = parent;
