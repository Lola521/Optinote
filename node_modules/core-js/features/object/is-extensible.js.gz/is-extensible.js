var parent = require('../../actual/object/is-extensible');

module.exports = parent;
