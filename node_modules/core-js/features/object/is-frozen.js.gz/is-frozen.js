var parent = require('../../actual/object/is-frozen');

module.exports = parent;
