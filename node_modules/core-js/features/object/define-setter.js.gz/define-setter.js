var parent = require('../../actual/object/define-setter');

module.exports = parent;
