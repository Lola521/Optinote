var parent = require('../../actual/object/is');

module.exports = parent;
