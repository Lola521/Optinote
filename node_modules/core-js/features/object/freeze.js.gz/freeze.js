var parent = require('../../actual/object/freeze');

module.exports = parent;
