var parent = require('../../actual/object/lookup-setter');

module.exports = parent;
