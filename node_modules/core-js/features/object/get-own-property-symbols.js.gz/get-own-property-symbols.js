var parent = require('../../actual/object/get-own-property-symbols');

module.exports = parent;
