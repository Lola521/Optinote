var parent = require('../../actual/object/create');

module.exports = parent;
