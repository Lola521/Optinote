var parent = require('../../actual/object/define-properties');

module.exports = parent;
