var parent = require('../../actual/object/set-prototype-of');

module.exports = parent;
