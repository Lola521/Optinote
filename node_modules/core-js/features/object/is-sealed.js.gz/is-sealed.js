var parent = require('../../actual/object/is-sealed');

module.exports = parent;
