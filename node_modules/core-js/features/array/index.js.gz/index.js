var parent = require('../../actual/array');
require('../../modules/es.promise');
require('../../modules/esnext.array.from-async');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.array.at');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.array.filter-out');
require('../../modules/esnext.array.filter-reject');
require('../../modules/esnext.array.is-template-object');
require('../../modules/esnext.array.last-item');
require('../../modules/esnext.array.last-index');
require('../../modules/esnext.array.to-reversed');
require('../../modules/esnext.array.to-sorted');
require('../../modules/esnext.array.to-spliced');
require('../../modules/esnext.array.unique-by');
require('../../modules/esnext.array.with');

module.exports = parent;
