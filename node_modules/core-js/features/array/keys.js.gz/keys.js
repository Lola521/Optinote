var parent = require('../../actual/array/keys');

module.exports = parent;
