var parent = require('../../actual/array/entries');

module.exports = parent;
