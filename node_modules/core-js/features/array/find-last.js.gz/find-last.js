var parent = require('../../actual/array/find-last');

module.exports = parent;
