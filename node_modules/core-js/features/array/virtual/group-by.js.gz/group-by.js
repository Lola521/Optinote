var parent = require('../../../actual/array/virtual/group-by');

module.exports = parent;
