var parent = require('../../../actual/array/virtual/concat');

module.exports = parent;
