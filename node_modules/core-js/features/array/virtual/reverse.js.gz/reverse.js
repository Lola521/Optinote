var parent = require('../../../actual/array/virtual/reverse');

module.exports = parent;
