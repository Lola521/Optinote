var parent = require('../../../actual/array/virtual/map');

module.exports = parent;
