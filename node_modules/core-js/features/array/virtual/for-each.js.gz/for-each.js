var parent = require('../../../actual/array/virtual/for-each');

module.exports = parent;
