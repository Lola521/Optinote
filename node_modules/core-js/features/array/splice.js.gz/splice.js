var parent = require('../../actual/array/splice');

module.exports = parent;
