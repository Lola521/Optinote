var parent = require('../../actual/array/for-each');

module.exports = parent;
