var parent = require('../../actual/array/values');

module.exports = parent;
