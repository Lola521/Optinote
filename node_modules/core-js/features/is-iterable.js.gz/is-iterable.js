var parent = require('../actual/is-iterable');

module.exports = parent;
