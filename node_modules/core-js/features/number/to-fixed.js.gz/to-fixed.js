var parent = require('../../actual/number/to-fixed');

module.exports = parent;
