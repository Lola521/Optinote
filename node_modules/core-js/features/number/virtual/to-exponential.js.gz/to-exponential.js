var parent = require('../../../actual/number/virtual/to-exponential');

module.exports = parent;
