var parent = require('../../../actual/number/virtual/to-precision');

module.exports = parent;
