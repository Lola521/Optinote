var parent = require('../../actual/number/min-safe-integer');

module.exports = parent;
