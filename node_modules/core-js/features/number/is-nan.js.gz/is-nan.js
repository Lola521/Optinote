var parent = require('../../actual/number/is-nan');

module.exports = parent;
