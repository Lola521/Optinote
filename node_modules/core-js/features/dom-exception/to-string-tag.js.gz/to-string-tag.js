var parent = require('../../actual/dom-exception/to-string-tag');

module.exports = parent;
