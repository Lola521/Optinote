var parent = require('../../actual/symbol/to-string-tag');

module.exports = parent;
