var parent = require('../../actual/symbol/has-instance');

module.exports = parent;
