var parent = require('../../actual/symbol/search');

module.exports = parent;
