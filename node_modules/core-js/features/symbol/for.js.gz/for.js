var parent = require('../../actual/symbol/for');

module.exports = parent;
