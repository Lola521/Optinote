var parent = require('../../actual/function/name');

module.exports = parent;
