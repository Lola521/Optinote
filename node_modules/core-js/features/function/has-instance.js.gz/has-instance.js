var parent = require('../../actual/function/has-instance');

module.exports = parent;
