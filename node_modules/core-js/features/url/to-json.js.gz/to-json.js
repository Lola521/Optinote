var parent = require('../../actual/url/to-json');

module.exports = parent;
