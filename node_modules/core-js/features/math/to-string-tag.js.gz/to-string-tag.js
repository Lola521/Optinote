var parent = require('../../actual/math/to-string-tag');

module.exports = parent;
