var parent = require('../../actual/math/hypot');

module.exports = parent;
