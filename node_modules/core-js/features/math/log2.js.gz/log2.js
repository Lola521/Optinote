var parent = require('../../actual/math/log2');

module.exports = parent;
