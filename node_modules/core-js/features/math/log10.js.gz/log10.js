var parent = require('../../actual/math/log10');

module.exports = parent;
