var parent = require('../../actual/math/cosh');

module.exports = parent;
