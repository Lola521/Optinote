var parent = require('../../actual/math/log1p');

module.exports = parent;
