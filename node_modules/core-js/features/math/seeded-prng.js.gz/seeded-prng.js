require('../../modules/esnext.math.seeded-prng');
var path = require('../../internals/path');

module.exports = path.Math.seededPRNG;
