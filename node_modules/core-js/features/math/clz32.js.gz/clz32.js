var parent = require('../../actual/math/clz32');

module.exports = parent;
