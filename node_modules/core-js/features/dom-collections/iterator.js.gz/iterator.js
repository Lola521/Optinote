var parent = require('../../actual/dom-collections/iterator');

module.exports = parent;
