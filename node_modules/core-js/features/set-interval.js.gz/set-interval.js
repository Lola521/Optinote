var parent = require('../actual/set-interval');

module.exports = parent;
