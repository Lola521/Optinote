// TODO: remove from `core-js@4`
require('../modules/esnext.aggregate-error');

var parent = require('../actual/aggregate-error');

module.exports = parent;
