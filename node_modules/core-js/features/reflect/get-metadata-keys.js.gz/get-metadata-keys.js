require('../../modules/esnext.reflect.get-metadata-keys');
var path = require('../../internals/path');

module.exports = path.Reflect.getMetadataKeys;
