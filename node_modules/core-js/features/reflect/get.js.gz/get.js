var parent = require('../../actual/reflect/get');

module.exports = parent;
