var parent = require('../../actual/reflect/is-extensible');

module.exports = parent;
