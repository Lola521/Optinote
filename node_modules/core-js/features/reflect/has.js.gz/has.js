var parent = require('../../actual/reflect/has');

module.exports = parent;
