var parent = require('../../actual/instance/pad-end');

module.exports = parent;
