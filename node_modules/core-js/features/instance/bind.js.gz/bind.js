var parent = require('../../actual/instance/bind');

module.exports = parent;
