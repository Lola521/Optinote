var parent = require('../../actual/instance/index-of');

module.exports = parent;
