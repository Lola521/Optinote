var parent = require('../../actual/instance/group-by');

module.exports = parent;
