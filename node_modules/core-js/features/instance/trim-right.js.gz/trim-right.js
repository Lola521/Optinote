var parent = require('../../actual/instance/trim-right');

module.exports = parent;
