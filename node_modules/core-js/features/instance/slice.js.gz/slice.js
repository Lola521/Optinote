var parent = require('../../actual/instance/slice');

module.exports = parent;
