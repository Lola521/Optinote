var parent = require('../../actual/instance/find-last-index');

module.exports = parent;
