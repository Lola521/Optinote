var parent = require('../../actual/instance/for-each');

module.exports = parent;
