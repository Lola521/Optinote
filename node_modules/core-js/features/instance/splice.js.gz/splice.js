var parent = require('../../actual/instance/splice');

module.exports = parent;
