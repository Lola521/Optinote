var parent = require('../../actual/instance/reverse');

module.exports = parent;
