var parent = require('../../actual/instance/ends-with');

module.exports = parent;
