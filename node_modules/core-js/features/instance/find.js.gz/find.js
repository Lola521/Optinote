var parent = require('../../actual/instance/find');

module.exports = parent;
