var parent = require('../../actual/instance/map');

module.exports = parent;
