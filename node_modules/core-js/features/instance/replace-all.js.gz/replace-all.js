var parent = require('../../actual/instance/replace-all');

module.exports = parent;
