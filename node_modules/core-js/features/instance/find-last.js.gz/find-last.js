var parent = require('../../actual/instance/find-last');

module.exports = parent;
