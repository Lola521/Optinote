var parent = require('../../actual/promise/finally');

module.exports = parent;
