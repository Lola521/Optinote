var parent = require('../../actual/promise/any');

// TODO: Remove from `core-js@4`
require('../../modules/esnext.aggregate-error');
require('../../modules/esnext.promise.any');

module.exports = parent;
