var parent = require('../../actual/json/to-string-tag');

module.exports = parent;
