var parent = require('../../actual/string/pad-start');

module.exports = parent;
