var parent = require('../../actual/string/match');

module.exports = parent;
