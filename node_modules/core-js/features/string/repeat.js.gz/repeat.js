var parent = require('../../actual/string/repeat');

module.exports = parent;
