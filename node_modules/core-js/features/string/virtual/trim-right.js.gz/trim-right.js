var parent = require('../../../actual/string/virtual/trim-right');

module.exports = parent;
