var parent = require('../../../actual/string/virtual/bold');

module.exports = parent;
