var parent = require('../../../actual/string/virtual/trim-end');

module.exports = parent;
