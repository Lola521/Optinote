var parent = require('../../../actual/string/virtual/trim-left');

module.exports = parent;
