var parent = require('../../../actual/string/virtual/substr');

module.exports = parent;
