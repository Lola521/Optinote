var parent = require('../../../actual/string/virtual/includes');

module.exports = parent;
