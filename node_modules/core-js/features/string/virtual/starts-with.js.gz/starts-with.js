var parent = require('../../../actual/string/virtual/starts-with');

module.exports = parent;
