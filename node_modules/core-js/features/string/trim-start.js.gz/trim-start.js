var parent = require('../../actual/string/trim-start');

module.exports = parent;
