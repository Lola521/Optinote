var parent = require('../../actual/string/includes');

module.exports = parent;
