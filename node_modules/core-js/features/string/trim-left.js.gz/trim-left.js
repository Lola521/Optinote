var parent = require('../../actual/string/trim-left');

module.exports = parent;
