var parent = require('../../actual/string/trim');

module.exports = parent;
