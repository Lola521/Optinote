var parent = require('../../actual/string/big');

module.exports = parent;
