var parent = require('../../actual/string/search');

module.exports = parent;
