var parent = require('../../actual/string/sup');

module.exports = parent;
