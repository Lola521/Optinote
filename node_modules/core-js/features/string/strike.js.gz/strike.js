var parent = require('../../actual/string/strike');

module.exports = parent;
