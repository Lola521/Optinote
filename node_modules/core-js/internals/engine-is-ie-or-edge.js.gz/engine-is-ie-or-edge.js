var UA = require('../internals/engine-user-agent');

module.exports = /MSIE|Trident/.test(UA);
