'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const MEDIA_QUERY = exports.MEDIA_QUERY = 'media query';
const PROPERTY = exports.PROPERTY = 'property';
const SELECTOR = exports.SELECTOR = 'selector';
const VALUE = exports.VALUE = 'value';