'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const FF_2 = exports.FF_2 = 'firefox 2';
const IE_5_5 = exports.IE_5_5 = 'ie 5.5';
const IE_6 = exports.IE_6 = 'ie 6';
const IE_7 = exports.IE_7 = 'ie 7';
const IE_8 = exports.IE_8 = 'ie 8';
const OP_9 = exports.OP_9 = 'opera 9';