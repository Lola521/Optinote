'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const ATRULE = exports.ATRULE = 'atrule';
const DECL = exports.DECL = 'decl';
const RULE = exports.RULE = 'rule';