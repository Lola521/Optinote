/*
 * Load this dynamically so that it
 * doesn't appear in the rollup bundle.
 */

module.exports.features = require('../../data/features')
