const set = require('regenerate')(0x118FF);
set.addRange(0x118A0, 0x118F2);
module.exports = set;
