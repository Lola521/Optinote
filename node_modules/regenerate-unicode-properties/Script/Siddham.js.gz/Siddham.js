const set = require('regenerate')();
set.addRange(0x11580, 0x115B5).addRange(0x115B8, 0x115DD);
module.exports = set;
