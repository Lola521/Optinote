const set = require('regenerate')();
set.addRange(0x0, 0x1F).addRange(0x7F, 0x9F);
module.exports = set;
