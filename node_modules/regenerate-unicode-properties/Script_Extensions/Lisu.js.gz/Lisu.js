const set = require('regenerate')(0x11FB0);
set.addRange(0xA4D0, 0xA4FF);
module.exports = set;
