const set = require('regenerate')(0x640);
set.addRange(0x10AC0, 0x10AE6).addRange(0x10AEB, 0x10AF6);
module.exports = set;
