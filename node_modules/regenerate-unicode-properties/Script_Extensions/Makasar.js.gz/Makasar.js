const set = require('regenerate')();
set.addRange(0x11EE0, 0x11EF8);
module.exports = set;
