"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = clone;

var _cloneNode = require("./cloneNode");

function clone(node) {
  return (0, _cloneNode.default)(node, false);
}