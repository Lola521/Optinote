"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regeneratorTransform = require("regenerator-transform");

var _default = _regeneratorTransform.default;
exports.default = _default;