# @babel/plugin-syntax-optional-chaining

> Allow parsing of optional properties

See our website [@babel/plugin-syntax-optional-chaining](https://babeljs.io/docs/en/next/babel-plugin-syntax-optional-chaining.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-optional-chaining
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-optional-chaining --dev
```
