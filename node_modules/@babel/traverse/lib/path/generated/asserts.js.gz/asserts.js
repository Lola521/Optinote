"use strict";

var t = require("@babel/types");

var _index = require("../index");