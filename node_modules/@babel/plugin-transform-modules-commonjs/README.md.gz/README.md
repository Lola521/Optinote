# @babel/plugin-transform-modules-commonjs

> This plugin transforms ES2015 modules to CommonJS

See our website [@babel/plugin-transform-modules-commonjs](https://babeljs.io/docs/en/babel-plugin-transform-modules-commonjs) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-modules-commonjs
```

or using yarn:

```sh
yarn add @babel/plugin-transform-modules-commonjs --dev
```
